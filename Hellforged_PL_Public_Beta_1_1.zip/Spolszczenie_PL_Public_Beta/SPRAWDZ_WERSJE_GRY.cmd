@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0HF_PL_Public_Beta.ps1" -Action Check
set "HF_RESULT=%ERRORLEVEL%"
echo.
pause
exit /b %HF_RESULT%
