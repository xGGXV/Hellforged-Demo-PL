﻿param(
    [ValidateSet('Install','Restore','Check')]
    [string]$Action = 'Install'
)
# Hellforged Demo PL v16.6 PUBLIC BETA 1.1 – patch-only, reversible.
# Supports: original game -> beta; v16.6 -> boss-test beta; beta -> original.
# An already installed identical beta DOES NOT require a prior backup.
$ErrorActionPreference = 'Stop'
$modDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$gameRoot = Split-Path -Parent $modDir
$gameFile = Join-Path $gameRoot 'Hellforged_Data\resources.assets'
$forwardPatch = Join-Path $modDir 'HF_PL_BETA.patch.gz'
$reversePatch = Join-Path $modDir 'HF_PL_BETA_RESTORE.patch.gz'
$backupDir = Join-Path $modDir 'Backup_PL_Public_Beta'
$backupFile = Join-Path $backupDir 'resources.assets.oryginal'
$temp = Join-Path $gameRoot 'Hellforged_Data\_HF_PL_PUBLIC_BETA.tmp'
$swap = Join-Path $gameRoot 'Hellforged_Data\_HF_PL_PUBLIC_BETA.swap'
$hOriginal = 'EDC1EE46CA323CA74F3F2B79CB8766F53A6CED3FA47A75C7230854FD5A6D3D4C'
$hOldPl = '982CB4B8A6C2558FE2D4069F9644F4AC8B08D920CC0E2F0D75A9F25F09AC4142'
$hBeta = '1A551F600A56F053CEB78F01CAD8D578882D05664AE8EBD02BF659509F8F593A'
$hForward = '73D0C8D5ABD8E18670776677A40F1DF4B09342B9F7A5087745B922A54E60675E'
$hReverse = 'EDF1EA4BD63BEA367FC507DB307EF9BE386C990A4452FCAF0B452C2C8B9CBBC7'
[long]$sizeOriginal = 58475256L
[long]$sizeBeta = 58471352L
[long]$bossOffset = 57044724L
function Fail([string]$msg) { throw $msg }
function SHA([string]$file) { return (Get-FileHash -LiteralPath $file -Algorithm SHA256 -ErrorAction Stop).Hash.ToUpperInvariant() }
function Copy-Exact([System.IO.Stream]$from, [System.IO.Stream]$to, [long]$n, [byte[]]$buf) {
    while ($n -gt 0) {
        [int]$wanted = [int][Math]::Min($n,[long]$buf.Length)
        [int]$got = $from.Read($buf,0,$wanted)
        if ($got -le 0) { Fail 'Nieoczekiwany koniec pliku.' }
        $to.Write($buf,0,$got)
        $n -= [long]$got
    }
}
function Build-Delta([string]$source, [string]$delta, [string]$deltaHash, [string]$magicExpected, [int]$countExpected, [long]$sizeExpected, [string]$hashExpected) {
    if (-not (Test-Path -LiteralPath $delta -PathType Leaf)) { Fail ('Brakuje latki: '+ $delta) }
    if ((SHA $delta) -ne $deltaHash) { Fail 'Niezgodna suma SHA-256 latki.' }
    $from=$null; $to=$null; $compressed=$null; $gzip=$null; $reader=$null
    try {
        $from = [System.IO.File]::OpenRead($source)
        $to = [System.IO.File]::Create($temp)
        $compressed = [System.IO.File]::OpenRead($delta)
        $gzip = [System.IO.Compression.GZipStream]::new($compressed,[System.IO.Compression.CompressionMode]::Decompress)
        $reader = [System.IO.BinaryReader]::new($gzip)
        [byte[]]$buf = New-Object byte[] 1048576
        $magic = [Text.Encoding]::ASCII.GetString($reader.ReadBytes(8))
        if ($magic -cne $magicExpected) { Fail 'Niezgodny format latki.' }
        [long]$count = [long]$reader.ReadUInt32()
        if ($count -ne $countExpected) { Fail 'Niezgodna liczba instrukcji latki.' }
        for ([long]$i=0; $i -lt $count; $i++) {
            [int]$mode = [int]$reader.ReadByte()
            if ($mode -eq 0) {
                [long]$off = [long]$reader.ReadUInt64()
                [long]$n = [long]$reader.ReadUInt32()
                if ($off -lt 0 -or $off + $n -gt $from.Length) { Fail 'Instrukcja latki poza granicami pliku.' }
                $from.Position = $off
                Copy-Exact $from $to $n $buf
            } elseif ($mode -eq 1) {
                [int]$n = [int]$reader.ReadUInt32()
                if ($n -lt 0 -or $n -gt 1048576) { Fail 'Nieprawidlowa wielkosc danych latki.' }
                [byte[]]$data = $reader.ReadBytes($n)
                if ($data.Length -ne $n) { Fail 'Latka jest niekompletna.' }
                $to.Write($data,0,$n)
            } else { Fail 'Niedozwolony typ instrukcji latki.' }
        }
        if ($reader.BaseStream.ReadByte() -ne -1) { Fail 'Dodatkowe dane na koncu latki.' }
        if ($to.Length -ne $sizeExpected) { Fail 'Nieprawidlowy rozmiar pliku wynikowego.' }
    } finally {
        if ($reader -ne $null) { $reader.Dispose() }
        elseif ($gzip -ne $null) { $gzip.Dispose() }
        if ($compressed -ne $null) { $compressed.Dispose() }
        if ($to -ne $null) { $to.Dispose() }
        if ($from -ne $null) { $from.Dispose() }
    }
    if ((SHA $temp) -ne $hashExpected) { Fail 'Plik wynikowy nie przeszedl kontroli SHA-256.' }
}
function Build-UpgradeFromV166() {
    Copy-Item -LiteralPath $gameFile -Destination $temp -ErrorAction Stop
    $st=$null
    try {
        $st=[IO.File]::Open($temp,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
        $st.Position=$bossOffset
        [byte[]]$old=New-Object byte[] 16
        if ($st.Read($old,0,16) -ne 16) { Fail 'Nie mozna odczytac nazwy bossa.' }
        if ([Text.Encoding]::UTF8.GetString($old) -cne 'Książę Krypty') { Fail 'Nazwa bossa nie jest zgodna z v16.6.' }
        [byte[]]$new=[Text.Encoding]::UTF8.GetBytes('KSIĄŻĘ KRYPTY')
        if ($new.Length -ne 16) { Fail 'Niezgodna dlugosc nazwy bossa.' }
        $st.Position=$bossOffset; $st.Write($new,0,$new.Length)
    } finally { if ($st -ne $null) { $st.Dispose() } }
    if ((SHA $temp) -ne $hBeta) { Fail 'Test bossa nie przeszedl kontroli SHA-256.' }
}
function Replace-Verified([string]$hashBefore, [string]$hashAfter) {
    if ((SHA $gameFile) -ne $hashBefore -or (SHA $temp) -ne $hashAfter) { Fail 'Pliki zmienily sie podczas instalacji.' }
    $sourcePath = [IO.Path]::GetFullPath($temp)
    $targetPath = [IO.Path]::GetFullPath($gameFile)
    $backupPath = [IO.Path]::GetFullPath($swap)
    [IO.File]::Replace($sourcePath,$targetPath,$backupPath)
    if ((SHA $gameFile) -ne $hashAfter) {
        if ((Test-Path -LiteralPath $swap -PathType Leaf) -and (SHA $swap) -eq $hashBefore) {
            Copy-Item -LiteralPath $swap -Destination $gameFile -Force -ErrorAction Stop
        }
        Fail 'Podmiana nie powiodla sie. Zachowaj pliki kopii i odzyskiwania.'
    }
    if (-not (Test-Path -LiteralPath $swap -PathType Leaf) -or (SHA $swap) -ne $hashBefore) {
        Fail 'Nie mozna potwierdzic poprawnosci podmiany. Zachowaj plik .swap.'
    }
    Remove-Item -LiteralPath $swap -Force -ErrorAction Stop
}
function Check-Backup() {
    if (Test-Path -LiteralPath $backupFile -PathType Leaf) {
        if ((SHA $backupFile) -ne $hOriginal) { Fail 'Istniejaca kopia oryginalu jest niezgodna. Nie zostanie nadpisana.' }
        return $true
    }
    return $false
}
try {
    if (-not (Test-Path -LiteralPath $gameFile -PathType Leaf)) {
        Fail 'Nie znaleziono Hellforged_Data\resources.assets. Wypakuj folder Spolszczenie_PL_Public_Beta obok Hellforged_Data.'
    }
    $current = SHA $gameFile
    Write-Host ('Gra: '+$gameFile) -ForegroundColor Cyan
    Write-Host ('SHA256: '+$current)
    if ($Action -eq 'Check') {
        if ($current -eq $hOriginal) { Write-Host 'Wykryto zgodny, oryginalny plik gry.' -ForegroundColor Green }
        elseif ($current -eq $hOldPl) { Write-Host 'Wykryto v16.6 bez testu bossa. Mozna zaktualizowac do Public Beta.' -ForegroundColor Yellow }
        elseif ($current -eq $hBeta) { Write-Host 'Public Beta jest juz aktywna (identyczna z v16.6 + test bossa).' -ForegroundColor Green }
        else { Write-Host 'Nieznana wersja pliku. Instalator niczego nie zmieni.' -ForegroundColor Yellow }
        exit 0
    }
    if ((Test-Path -LiteralPath $temp -PathType Leaf) -or (Test-Path -LiteralPath $swap -PathType Leaf)) {
        Fail 'Pozostaly pliki tymczasowe .tmp/.swap. Niczego nie zmieniono; zachowaj je do diagnostyki.'
    }
    if ($Action -eq 'Install') {
        if ($current -eq $hBeta) {
            Write-Host 'GOTOWE: masz juz identyczne spolszczenie Public Beta v16.6 z poprawka bossa.' -ForegroundColor Green
            Write-Host 'Nie trzeba nic instalowac. Cofanie jest mozliwe z latki odwrotnej, bez starego Backup_v16_6.'
            exit 0
        }
        if ($current -ne $hOriginal -and $current -ne $hOldPl) {
            Fail 'Nieznana wersja gry. Dla bezpieczenstwa niczego nie zmieniono.'
        }
        if ($current -eq $hOriginal) {
            if (-not (Check-Backup)) {
                New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
                Copy-Item -LiteralPath $gameFile -Destination $backupFile -ErrorAction Stop
                if (-not (Check-Backup)) { Fail 'Nie udalo sie zapisac bezpiecznej kopii oryginalu.' }
            }
        } else {
            if (Test-Path -LiteralPath $backupFile -PathType Leaf) { $null=Check-Backup }
        }
        try {
            if ($current -eq $hOriginal) {
                Build-Delta $gameFile $forwardPatch $hForward 'HFPLPB01' 9781 $sizeBeta $hBeta
            } else {
                Build-UpgradeFromV166
            }
            Replace-Verified $current $hBeta
        } finally {
            if ((Test-Path -LiteralPath $temp -PathType Leaf) -and -not (Test-Path -LiteralPath $swap -PathType Leaf)) {
                Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue
            }
        }
        Write-Host 'GOTOWE: aktywowano Public Beta v16.6 (test KSIĄŻĘ KRYPTY).' -ForegroundColor Green
        exit 0
    }
    if ($Action -eq 'Restore') {
        if ($current -eq $hOriginal) { Write-Host 'Oryginal gry juz jest aktywny.' -ForegroundColor Green; exit 0 }
        if ($current -ne $hBeta) { Fail 'Odtwarzanie obsluguje tylko zgodna Public Beta. Nieznany plik pozostawiono bez zmian.' }
        try {
            if (Check-Backup) {
                Copy-Item -LiteralPath $backupFile -Destination $temp -ErrorAction Stop
                if ((SHA $temp) -ne $hOriginal) { Fail 'Nieprawidlowa kopia tymczasowa.' }
            } else {
                Write-Host 'Nie ma kopii sprzed instalacji. Odtwarzam oryginal z latki odwrotnej.' -ForegroundColor Yellow
                Build-Delta $gameFile $reversePatch $hReverse 'HFPLRV01' 9791 $sizeOriginal $hOriginal
            }
            Replace-Verified $hBeta $hOriginal
        } finally {
            if ((Test-Path -LiteralPath $temp -PathType Leaf) -and -not (Test-Path -LiteralPath $swap -PathType Leaf)) {
                Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue
            }
        }
        Write-Host 'GOTOWE: przywrocono oryginal gry z tej aktualizacji.' -ForegroundColor Green
        exit 0
    }
} catch {
    Write-Host ('BLAD: '+$_.Exception.Message) -ForegroundColor Red
    exit 1
}
