﻿# Hellforged Demo – polskie spolszczenie v16.6 PUBLIC BETA 1.1

**Nieoficjalne, fanowskie tłumaczenie gry. Wersja testowa dla społeczności.**

Paczka zawiera dwie małe łatki różnicowe (łącznie ok. 200 KB), **nie zawiera pełnego pliku `resources.assets` ani pakietów `.bundle`**. Instalator odtwarza spolszczony plik wyłącznie z oryginalnych zasobów na komputerze gracza. Do działania potrzebna jest legalnie zainstalowana gra Hellforged Demo na Windows.

## Zgodność

- Sprawdzona wersja pliku gry (oryginał): SHA-256 `EDC1EE46CA323CA74F3F2B79CB8766F53A6CED3FA47A75C7230854FD5A6D3D4C`.
- Oczekiwany plik po instalacji: SHA-256 `1A551F600A56F053CEB78F01CAD8D578882D05664AE8EBD02BF659509F8F593A`.
- Katalog lokalizacji: 3247 wpisów, tłumaczenie przeniesione z v16.5–v16.6.
- Unity 6000.5.8f1; kompatybilność z późniejszymi aktualizacjami **nie jest gwarantowana**.
- Spolszczenie zastępuje lokalizację **Deutsch**. Nie dodaje nowej pozycji „Polski” do menu.

Jeśli aktualizacja Steam zmieni `resources.assets`, instalator przerwie działanie. **Nie wyłączaj kontroli SHA-256 i nie podmieniaj pliku ręcznie.**

## Instalacja

1. Zamknij grę i poczekaj na zakończenie aktualizacji Steam.
2. Wypakuj cały folder `Spolszczenie_PL_Public_Beta` do **głównego folderu Hellforged Demo** – ma leżeć obok folderu `Hellforged_Data`, a nie wewnątrz niego.
3. Uruchom dwukrotnie `ZAINSTALUJ_POLSKI.cmd`. Instalator sam sprawdzi zgodność wersji, zapisze kopię oryginału i zbuduje plik z łatki.
4. Dopiero po komunikacie **GOTOWE** uruchom grę i w ustawieniach wybierz **Deutsch**.
5. Przetestuj menu, dialogi, opisy umiejętności i napisy bossów.

Możesz najpierw uruchomić `SPRAWDZ_WERSJE_GRY.cmd` – nie modyfikuje plików.

## Jeśli używasz już v16.6 TEST

Instalator obsługuje również v16.6 bez testu bossa. **Jeśli już masz v16.6 z testem bossa (SHA-256 zaczyna się od `1A551F60`), nie musi niczego instalować ani wymagać poprzedniej kopii zapasowej.** Odzyskanie oryginału jest możliwe za pomocą dołączonej łatki odwrotnej. Zachowaj dotychczasowe foldery Backup mimo że nie są wymagane do tego przejścia.

## Przywracanie oryginalnych plików

1. Zamknij grę.
2. Uruchom `PRZYWROC_ORYGINAL.cmd` w tym samym folderze.
3. Instalator porówna sumy i przywróci plik z `Backup_PL_Public_Beta`; jeśli kopia nie istnieje, odbuduje oryginał za pomocą zweryfikowanej łatki odwrotnej.

Zachowaj katalog `Backup_PL_Public_Beta`, jeśli istnieje. Jeśli plik zmienił się w wyniku kolejnej aktualizacji gry, cofanie tej konkretnej wersji zostanie zablokowane, aby nie nadpisać nowszych zasobów.

## Znane ograniczenia

- Nieoficjalna wersja beta, nieprzetestowana na wszystkich komputerach i wersjach Windows.
- Weryfikacja struktury i sum SHA-256 została wykonana; **kompletny test językowy wszystkich ekranów i wszystkich glifów nie został wykonany**.
- Nagłówek bossa Książę Krypty zapisano testowo jako `KSIĄŻĘ KRYPTY`, aby obejść błędne formatowanie wielkich liter. Inne duże napisy mogą nadal wyświetlać się niejednolicie.
- TextMeshPro: czcionka Cinzel nie zawiera większości polskich znaków; nie modyfikowano fontów ani innych pakietów gry.
- W tłumaczeniu mogą pozostać angielskie komunikaty i nienaturalne opisy umiejętności. Prosimy o zrzuty ekranu.

## Bezpieczeństwo i prywatność

- Instalator nie łączy się z Internetem, niczego nie pobiera i nie zbiera danych.
- Modyfikuje tylko lokalny `Hellforged_Data\resources.assets` (oraz tworzy kopię i pliki tymczasowe).
- Sprawdza sumy wejściowego i wynikowego pliku oraz zawartość obu łatek (instalacji i cofania).
- Korzysta z wbudowanego PowerShell na Windows, nie wymaga instalowania dodatkowych aplikacji.
- Pliki `.ps1` i `.cmd` są jawne i można je otworzyć w edytorze tekstu.

## Jak zgłaszać błędy?

Skorzystaj z `ZGLOSZENIE_BLEDU.md`. Najbardziej przydatne są zrzuty ekranu pokazujące cały interfejs i lokalizację błędnego napisu, nazwę ekranu/umiejętności oraz informację, czy problem występuje także po ponownym uruchomieniu gry.

## Informacja prawna

Nieoficjalne tłumaczenie społecznościowe. Hellforged i oryginalne zasoby gry należą do ich właścicieli. Paczka nie zawiera kompletnych plików gry. Przed publicznym zamieszczeniem sprawdź aktualny regulamin wybranego serwisu oraz zasady wydawcy gry dotyczące dystrybucji modyfikacji; w razie wątpliwości uzyskaj zgodę twórców.
