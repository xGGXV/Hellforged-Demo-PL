﻿# Dziennik wersji

## v16.6 Public Beta 1.1 – 6 listopada 2026 r.

- Naprawiono błąd wymagający starej kopii zapasowej, gdy identyczna wersja beta jest już zainstalowana.
- Instalator akceptuje istniejące spolszczenie v16.6 bez testu bossa i aktualizuje tylko nazwę bossa.
- Dodano zweryfikowaną małą łatkę odwrotną do przywracania oryginału nawet bez starego folderu Backup.
- Bez zmian w tekstach tłumaczenia w porównaniu do Public Beta 1.

## v16.6 Public Beta 1 – 6 listopada 2026 r.

- Pierwsza paczka przygotowana do społecznościowych testów.
- Zamiast pełnego `resources.assets`: mała łatka różnicowa działająca na ściśle określonej wersji gry.
- Tłumaczenie z działającej wersji v16.6, katalog obejmuje 3247 wpisów.
- Włączony testowy, poprawnie zapisany wielkimi literami nagłówek „KSIĄŻĘ KRYPTY”.
- Kontrola sum SHA-256, backup i przywracanie oryginału.
- Pełne testy tekstów i czcionek nadal trwają.
