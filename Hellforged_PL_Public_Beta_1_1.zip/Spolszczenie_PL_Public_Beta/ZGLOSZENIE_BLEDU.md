﻿# Zgłoszenie błędu spolszczenia – Hellforged Demo PL v16.6 PUBLIC BETA

**Miejsce w grze / ekran:**

**Oczekiwany napis / znaczenie:**

**Napis widoczny w grze:**

**Typ problemu:** literówka / błędna odmiana / angielski tekst / czcionka lub polskie znaki / wielkie litery / inny

**Kroki, aby odtworzyć problem:**

**Czy błąd występuje po ponownym uruchomieniu gry?** tak / nie / nie sprawdzono

**Wersja gry (jeśli znana):**

**Zrzut ekranu:** dołącz plik PNG/JPG, najlepiej cały ekran; nie umieszczaj danych osobowych.

**Dodatkowe informacje:**
