﻿# Hellforged Demo – polskie spolszczenie v16.6 PUBLIC BETA [nieoficjalne]

Udostępniamy pierwszą publiczną wersję beta polskiego tłumaczenia **Hellforged Demo** na Windows. Tłumaczenie obejmuje katalog lokalizacji gry zawierający 3247 wpisów. Do testowania zapraszamy wszystkich, którzy chcą pomóc poprawić jakość polskich napisów.

**Instalacja:** rozpakuj folder `Spolszczenie_PL_Public_Beta` obok `Hellforged_Data`, uruchom `ZAINSTALUJ_POLSKI.cmd`, a następnie wybierz w grze język **Deutsch** (jego miejsce zajmuje polskie tłumaczenie).

**Ważne:** jest to łatka przeznaczona wyłącznie do wskazanej w instrukcji wersji gry. Instalator sprawdza zgodność plików, tworzy kopię zapasową i umożliwia cofnięcie zmian. Nie zawiera kompletnych plików gry.

**Stan:** beta – mogą nadal występować błędy językowe, angielskie komunikaty oraz problemy z polskimi znakami i dużymi literami. Testowany napis „KSIĄŻĘ KRYPTY” został już uwzględniony, ale innych nazw bossów nie zweryfikowano w pełni.

**Pomóż w testach:** zgłaszaj nieprzetłumaczone teksty, nienaturalne opisy umiejętności i błędne czcionki. Najlepiej dołącz pełny zrzut ekranu i podaj miejsce występowania problemu.

To fanowskie, nieoficjalne tłumaczenie, niezwiązane z twórcami gry. Kompatybilność z przyszłymi aktualizacjami nie jest gwarantowana.
